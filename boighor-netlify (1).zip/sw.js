/* বইঘর service worker
   - App files (index.html, manifest, icons): network first (new versions arrive quickly), cached copy when offline.
   - CDN files the page needs (Tailwind, Font Awesome, Google Fonts): cached on first use and pre-cached on install, so the app also opens offline.
   - Everything else (AI services, Wikipedia, Google Books...) is NOT touched and always goes to the network.
   The library itself (books, covers, settings) lives in IndexedDB, not here, so updating this file never touches your data. */

const VERSION = 'boighor-2026-11-18-icon';
const SHELL_CACHE = VERSION + '-shell';
const CDN_CACHE = 'boighor-cdn-v1';

const SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png'
];

const CDN_HOSTS = ['cdn.tailwindcss.com', 'cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com'];

const CDN_PRECACHE = [
  'https://cdn.tailwindcss.com',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
  'https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap'
];

// Only the font files the app really uses: Bengali + Latin text and the three Font Awesome icon sets (woff2 only)
const GOOGLE_SUBSETS = ['bengali', 'latin', 'latin-ext'];

async function precacheCdn(cache) {
  await Promise.allSettled(CDN_PRECACHE.map(async (url) => {
    const isCss = /\.css(\?|$)|fonts\.googleapis\.com/.test(url);
    const res = await fetch(url, isCss ? { mode: 'cors' } : { mode: 'no-cors' });
    if (!(res.ok || res.type === 'opaque')) return;
    await cache.put(url, res.clone());
    if (!isCss) return;

    // Pull in the font files that this stylesheet points to, so icons and Bengali text also work offline after the very first visit
    const css = await res.text();
    const fontUrls = new Set();
    if (url.includes('fonts.googleapis.com')) {
      const re = /\/\*\s*([\w-]+)\s*\*\/\s*@font-face\s*\{[^}]*?src:\s*url\(([^)]+)\)/g;
      let m;
      while ((m = re.exec(css))) {
        if (GOOGLE_SUBSETS.includes(m[1])) fontUrls.add(m[2].replace(/['"]/g, ''));
      }
    } else {
      const re = /url\(([^)]+\.woff2[^)]*)\)/g;
      let m;
      while ((m = re.exec(css))) fontUrls.add(new URL(m[1].replace(/['"]/g, ''), url).href);
    }
    await Promise.allSettled([...fontUrls].map(async (fu) => {
      const fr = await fetch(fu, { mode: 'cors' });
      if (fr.ok) await cache.put(fu, fr);
    }));
  }));
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const shell = await caches.open(SHELL_CACHE);
    await shell.addAll(SHELL.map((u) => new Request(u, { cache: 'reload' })));
    const cdn = await caches.open(CDN_CACHE);
    await precacheCdn(cdn);           // best effort: never blocks the install if the CDN is unreachable
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keep = new Set([SHELL_CACHE, CDN_CACHE]);
    const names = await caches.keys();
    await Promise.all(names.filter((n) => !keep.has(n)).map((n) => caches.delete(n)));
    await self.clients.claim();
  })());
});

async function networkFirst(request) {
  const cache = await caches.open(SHELL_CACHE);
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 4000);   // slow or no network: fall back to the saved copy
    const res = await fetch(request, { signal: ctrl.signal });
    clearTimeout(timer);
    if (res && res.ok && res.type === 'basic') cache.put(request, res.clone());
    return res;
  } catch (err) {
    const hit = (await cache.match(request, { ignoreSearch: true }))
      || (request.mode === 'navigate' ? (await cache.match('./index.html')) || (await cache.match('./')) : null);
    return hit || new Response('অফলাইন — অ্যাপ এখনও সংরক্ষিত হয়নি। একবার ইন্টারনেট চালু করে খুলুন।', {
      status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' }
    });
  }
}

async function cdnCacheFirst(event) {
  const cache = await caches.open(CDN_CACHE);
  const hit = await cache.match(event.request, { ignoreVary: true });
  const refresh = fetch(event.request).then((res) => {
    if (res && (res.ok || res.type === 'opaque')) cache.put(event.request, res.clone());
    return res;
  }).catch(() => null);
  if (hit) { event.waitUntil(refresh); return hit; }
  return (await refresh) || Response.error();
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === self.location.origin) {
    event.respondWith(networkFirst(req));
  } else if (CDN_HOSTS.includes(url.hostname)) {
    event.respondWith(cdnCacheFirst(event));
  }
});
